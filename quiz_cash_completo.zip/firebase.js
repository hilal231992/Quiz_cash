// CONFIGURAZIONE FIREBASE (Sostituisci con i tuoi dati reali)
const firebaseConfig = {
  apiKey: "INSERISCI_API_KEY",
  authDomain: "INSERISCI_PROGETTO.firebaseapp.com",
  projectId: "INSERISCI_PROGETTO",
  storageBucket: "INSERISCI_PROGETTO.appspot.com",
  messagingSenderId: "INSERISCI_SENDER_ID",
  appId: "INSERISCI_APP_ID",
  databaseURL: "https://INSERISCI_PROGETTO.firebaseio.com"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();

let currentUser = null;
let punti = 0;

function loginGoogle() {
  const provider = new firebase.auth.GoogleAuthProvider();
  auth.signInWithPopup(provider).then((result) => {
    currentUser = result.user;
    document.getElementById("loginStatus").innerText = "Ciao, " + currentUser.displayName;
    caricaPunti();
  }).catch((error) => {
    console.error("Errore login:", error);
  });
}

function caricaPunti() {
  if (!currentUser) return;
  db.ref("utenti/" + currentUser.uid + "/punti").once("value", (snapshot) => {
    punti = snapshot.val() || 0;
    aggiornaPunti();
  });
}

function aggiungiPunti(p) {
  punti += p;
  aggiornaPunti();
  if (currentUser) {
    db.ref("utenti/" + currentUser.uid + "/punti").set(punti);
  }
}

function aggiornaPunti() {
  document.getElementById("score").innerText = "Punti: " + punti;
}
